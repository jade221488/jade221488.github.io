#include <iostream>
#include <limits>
#include <string>
#include <cctype>
#include <cstring>

using namespace std;

//Initializing global buffer size variable
constexpr size_t bufferSize = 20;

//Declaring Functions: Buffer Overflow Check, Sanitization, and Validation
bool checkBufferOverflow(char userInput[], size_t bufferSizeLimit);
void sanitizeInput(char userInput[]);
bool validateInput(const char userInput[]);


//Main function
int main()
{
    //Declare and Initialize Varaibles
    const string account_number = "CharlieBrown42";
    char userInput[bufferSize];
    
    //Prompt User to Enter a Value
    cout << "Buffer Overflow Example" << endl;
    cout << "Enter a value: ";

    //Call checkBufferOverflow to check for buffer overflow, if true end program
    if (checkBufferOverflow(userInput, sizeof(userInput))){
        
        return 1;
    }
        
    //Call sanitizeInput to strip input of whitespace and non-printable characters
    sanitizeInput(userInput);
    
    //Call validateInput to check input matches expected format, if not true end program
    if (!validateInput(userInput)){
            
        return 1;
    }
            
    //Display user's input and account number if user's input not exceed array bounds, is sanitized, and validated
    cout << "You entered: " << userInput << endl;
    cout << "Account Number = " << account_number << endl;
    
    return 0;
}


//Initializing Functions: Buffer Overflow Check, Sanitization, and Validation

//BUFFER OVERFLOW CHECK
bool checkBufferOverflow(char userInput[], size_t bufferSizeLimit){
    
    //Safely read characters in userInput up to bufferSizeLimit - 1
    cin.get(userInput, bufferSizeLimit);
    
    //Check if the input stream is not at the end and the next character is not a newline
    if (!cin.eof() && cin.peek() != '\n') {

        //Prompt user that input exceeds capacity
        cout << "Buffer overflow attempt detected." << endl;

        //Ignore the remaining unread characters in the input stream up to the next newline
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        
        //Return true, indicating that buffer overflow occured
        return true;
    }
    
    //Check if the next character in the input stream is a newline
    if (cin.peek() == '\n'){
        
        //Get and discard the next character if it is a newline character
        cin.get();
    }
    
    //Return false if userInput was able to fit within buffer bounds
    return false;
}

//SANITIZE INPUT
void sanitizeInput(char userInput[]){
    
    //Check if array pointer is null, if true end program
    if (userInput == nullptr){
        
        //Notify user userInput is empty
        cout << "Input is empty, cannot sanitize" << endl;
        
        return;
    }
    
    //Part One: remove non-printable characters
    //Initialize writeIndex counter
    size_t writeIndex = 0;
    
    //Loop until it reaches null terminator in character array
    for (size_t readIndex = 0; userInput[readIndex] != '\0'; ++readIndex){
        
        //Check if the current character is printable
        if (isprint(static_cast<unsigned char>(userInput[readIndex]))){
            
            //Copy character to writeIndex and increment by one
            userInput[writeIndex++] = userInput[readIndex];
        }
    }
    
    //Add null terminator to end of writeIndex after filtering characters
    userInput[writeIndex] = '\0';
    
    //Get new length of array after removing non-printable characters
    size_t inputLength = strlen(userInput);
    
    //Part Two: trim off excess whitespace
    //Loop starting from the end of the array
    while (inputLength > 0 && isspace(static_cast<unsigned char>(userInput[inputLength - 1]))){
        
        //Decrement the inputLength counter and overwrite trailing whitespace with null terminator
        userInput[--inputLength] = '\0';
    }
    
    //Part Three: trim off leading whitespace
    //Initialize starting index
    size_t beginning = 0;
    
    //Loop while current chracter is not null terminator and is whitespace character
    while(userInput[beginning] != '\0' && isspace(static_cast<unsigned char>(userInput[beginning]))){
        
        //Increment index counter
        beginning++;
    }
    
    //Check if whitespace characters were found
    if(beginning > 0){
        
        //Shift the array contents to the left
        memmove(userInput, userInput + beginning, strlen(userInput + beginning) + 1);
    }
}

//VALIDATE INPUT
bool validateInput(const char userInput[]){
    
    //Get the length of userInput
    size_t inputLength = strlen(userInput);
    
    //Check if length of userInput is empty, if true return back to Main function
    if(inputLength == 0){
        
        //Notify user input is empty, cannot validate
        cout << "Input is empty, cannot validate." << endl;
        
        //Return false if userInput failed validation
        return false;
    }
    
    //Loop through each character
    for (size_t i = 0; i < inputLength; ++i){
        
        //Check if character is not a letter or number, if true return back to Main function
        if(!isalnum(static_cast<unsigned char>(userInput[i]))){
            
            //Notify user input failed validation
            cout << "Input failed to validate, contains content other than a letter or number." << endl;
            
            //Return false if userInput failed validation
            return false;
        }
    }
    
    //Return true if userInput passed validation
    return true;
}
