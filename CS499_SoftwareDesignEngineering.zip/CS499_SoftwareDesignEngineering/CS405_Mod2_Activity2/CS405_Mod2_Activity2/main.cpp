// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>
#include <limits>

using namespace std;

int main()
{
    std::cout << "Buffer Overflow Example" << std::endl;

    // TODO: The user can type more than 20 characters and overflow the buffer, resulting in account_number being replaced -
    //  even though it is a constant and the compiler buffer overflow checks are on.
    //  You need to modify this method to prevent buffer overflow without changing the account_number
    //  variable, and its position in the declaration. It must always be directly before the variable used for input.
    //  You must notify the user if they entered too much data.

    const std::string account_number = "CharlieBrown42";
    char user_input[20];
    std::cout << "Enter a value: ";

    //prevent the user from entering more characters than what the buffer can hold
    cin.width(sizeof(user_input));

    std::cin >> user_input;

    //check if the user attempted to enter too much input, if so output warning message
    if (!cin.eof() && cin.peek() != '\n') {

        cout << "Buffer overflow attempt detected" << endl;

        //clear extra data that was input
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        return 1;
    }

    std::cout << "You entered: " << user_input << std::endl;
    std::cout << "Account Number = " << account_number << std::endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

