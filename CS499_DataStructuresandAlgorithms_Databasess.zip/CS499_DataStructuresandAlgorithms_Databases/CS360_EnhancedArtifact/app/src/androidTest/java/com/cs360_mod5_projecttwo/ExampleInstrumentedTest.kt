package com.cs360_mod5_projecttwo

import android.content.Context
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Test
import org.junit.runner.RunWith
import org.junit.After
import org.junit.Assert.*
import org.junit.Before

//=============================================================================
//Tests on real SQLite database actions, user authentication, data isolation
//=============================================================================
@RunWith(AndroidJUnit4::class)
class ExampleInstrumentedTest {

    private lateinit var dbHelper: DBHelper
    private lateinit var context: Context

    //Set a clean database before test execution
    @Before
    fun setUp() {

        context = InstrumentationRegistry.getInstrumentation().targetContext
        context.deleteDatabase("weight_tracker.db")
        dbHelper = DBHelper(context)
    }

    //Clean database connections and removes tests after execution
    @After
    fun tearDown() {

        dbHelper.close()
        context.deleteDatabase("weight_tracker.db")
    }

    //Verify that app context is retrieved correctly and matches package name
    @Test
    fun useAppContext() {

        assertEquals("com.cs360_mod5_projecttwo", context.packageName)
    }

    //Three tests regarding user registration and login
    @Test
    fun testUserRegistrationAndLogin() {

        //1. test if successfully registered a new user with primary key greater than zero
        val newUserId = dbHelper.addUser("testuser", "password123", "Manchester")
        assertTrue("User registration should generate an ID > 0", newUserId > 0)

        //2. test with valid credentials
        val authenticateUserId = dbHelper.validateUser("testuser", "password123")
        assertEquals(newUserId.toInt(), authenticateUserId)

        //3. test with invalid credentials
        val invalidUserId = dbHelper.validateUser("testuser", "wrongpassword")
        assertEquals("Invalid password should return -1", -1, invalidUserId)
    }

    //Ensure data isolation between different user accounts, no data is globally shared
    @Test
    fun testMultiUserDataIsolation() {

        //create two users
        val user1Id = dbHelper.addUser("user1", "pass1", "Town1").toInt()
        val user2Id = dbHelper.addUser("user2", "pass2", "Town2").toInt()

        //insert weight entries for user 1
        dbHelper.addDailyWeight(user1Id, "09/30/26", 175.0F)
        dbHelper.addDailyWeight(user1Id, "10/01/2026", 174.0f)

        //insert weight entry for user 2
        dbHelper.addDailyWeight(user2Id, "10/01/26", 187.0f)

        //assert user 1 only gets their two weight entries
        val user1Weights = dbHelper.getAllDailyWeights(user1Id)
        assertEquals("User 1 should have 2 weight logs", 2, user1Weights.size)

        //assert user 2 gets only one weight entry
        val user2Weights = dbHelper.getAllDailyWeights(user2Id)
        assertEquals("User 2 should have 1 weight log", 1, user2Weights.size)
        assertEquals("user 2's weight should be 187.0", "187.0", user2Weights[0].second)
    }

    //Test setting and getting a user's weight goal
    @Test
    fun testGoalWeightPerUser() {

        //create user
        val user1Id = dbHelper.addUser("user1", "pass1", "Town1").toInt()

        //set goal weight
        dbHelper.setGoalWeight(user1Id, 160.0f)

        //get goal weight
        val goalWeight = dbHelper.getGoalWeight(user1Id)

        //assert check if both values are the same
        assertEquals(160.0f, goalWeight, 0.01f)
    }
}