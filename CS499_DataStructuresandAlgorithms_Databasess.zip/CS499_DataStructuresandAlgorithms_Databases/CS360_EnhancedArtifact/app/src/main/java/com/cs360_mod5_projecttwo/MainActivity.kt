package com.cs360_mod5_projecttwo

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.ceil

//=============================================================================
//Main Activity handles weight goal, daily weight log, navigate to
// weight history screen, and prediction algorithm
//=============================================================================
class MainActivity : AppCompatActivity() {

    private lateinit var dbHelper: DBHelper
    private var currentUserId: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_screen)

        dbHelper = DBHelper(this)

        val sharedPref = getSharedPreferences("UserSessionPrefs", MODE_PRIVATE)
        currentUserId = intent.getIntExtra("USER_ID", sharedPref.getInt("KEY_USER_ID", -1))

        if (currentUserId == -1) {

            Toast.makeText(this, "Session expired. Please log in again", Toast.LENGTH_SHORT).show()
            startActivity(Intent(this, LoginActivity::class.java))

            finish()
            return
        }

        val goalProgressBar = findViewById<ProgressBar>(R.id.goalProgressBar)
        val goalText = findViewById<TextView>(R.id.goalText)
        val todayWeightEditText = findViewById<EditText>(R.id.todayWeightEditText)
        val updateGoalButton = findViewById<Button>(R.id.updateGoalButton)
        val viewHistoryButton = findViewById<Button>(R.id.viewHistoryButton)
        val logWeightButton = findViewById<Button>(R.id.logWeightButton)
        val predictionText = findViewById<TextView>(R.id.predictionText)

        refreshDashboard(goalProgressBar, goalText, predictionText)

        //=============================================================================
        //Update goal handler
        //=============================================================================

        updateGoalButton.setOnClickListener {

            val goalInput = todayWeightEditText.text.toString().trim()

            if (goalInput.isNotEmpty()) {

                try {

                    val newGoal = goalInput.toFloat()

                    if (newGoal > 0f) {

                        dbHelper.setGoalWeight(currentUserId, newGoal)
                        todayWeightEditText.text.clear()
                        refreshDashboard(goalProgressBar, goalText, predictionText)
                        Toast.makeText(this, "Goal weight updated", Toast.LENGTH_SHORT).show()
                    } else {

                        Toast.makeText(this, "Please enter a positive weight", Toast.LENGTH_SHORT).show()
                    }
                } catch (_: NumberFormatException) {

                    Toast.makeText(this, "Please enter a valid number", Toast.LENGTH_SHORT).show()
                }
            } else {

                Toast.makeText(this, "Enter a new goal weight", Toast.LENGTH_SHORT).show()
            }
        }

        //=============================================================================
        //Log daily weight handler
        //=============================================================================

        logWeightButton.setOnClickListener {

            val weightText = todayWeightEditText.text.toString().trim()

            if (weightText.isNotEmpty()) {

                try {

                    val weight = weightText.toFloat()

                    if (weight > 0f) {

                        val date = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
                        dbHelper.addDailyWeight(currentUserId, date, weight)
                        todayWeightEditText.text.clear()
                        refreshDashboard(goalProgressBar, goalText, predictionText)

                        Toast.makeText(this, "Today's weight logged", Toast.LENGTH_SHORT).show()
                    } else {

                        Toast.makeText(this, "Please enter a positive weight", Toast.LENGTH_SHORT).show()
                    }
                } catch (_: NumberFormatException) {

                    Toast.makeText(this, "Please enter a valid number", Toast.LENGTH_SHORT).show()
                }
            } else {

                Toast.makeText(this, "Enter today's weight first", Toast.LENGTH_SHORT).show()
            }
        }

        //=============================================================================
        //Navigate to view history screen handler
        //=============================================================================

        viewHistoryButton.setOnClickListener {

            val intent = Intent(this, WeightHistoryActivity::class.java).apply {
                putExtra("USER_ID", currentUserId)
            }

            startActivity(intent)
        }
    }

    //=============================================================================
    //Refresh dashboard when user navigates back to main screen
    //=============================================================================

    override fun onResume() {

        super.onResume()

        val goalProgressBar = findViewById<ProgressBar>(R.id.goalProgressBar)
        val goalText = findViewById<TextView>(R.id.goalText)
        val predictionText = findViewById<TextView>(R.id.predictionText)

        if (currentUserId != -1) {

            refreshDashboard(goalProgressBar, goalText, predictionText)
        }
    }

    //=============================================================================
    //Gets data from dbHelper, updates progress bar, and displays message
    // for prediction algorithm
    //=============================================================================

    @SuppressLint("StringFormatMatches")
    private fun refreshDashboard(

        progressBar: ProgressBar,
        goalText: TextView,
        predictionText: TextView?
    ) {

        val goalWeight = dbHelper.getGoalWeight(currentUserId)
        val latestWeight = dbHelper.getLatestWeight(currentUserId)
        val weightHistory = dbHelper.getChronologicalWeights(currentUserId)
        val weightDates = dbHelper.getChronologicalDates(currentUserId)

        goalText.text = getString(R.string.goal_weight_format, goalWeight)

        if (latestWeight > 0f && goalWeight > 0f) {

            val startingWeight = weightHistory.firstOrNull() ?: latestWeight

            val progressPercentage = if (startingWeight == goalWeight) {

                100
            } else if (goalWeight < startingWeight) {

                if (latestWeight <= goalWeight) 100
                else (((startingWeight - latestWeight) / (startingWeight - goalWeight)) * 100).toInt()
                    .coerceIn(0, 100)
            } else {

                if (latestWeight >= goalWeight) 100
                else (((latestWeight - startingWeight) / (goalWeight - startingWeight)) * 100).toInt()
                    .coerceIn(0, 100)
            }

            progressBar.progress = progressPercentage
        } else {

            progressBar.progress = 0
        }

        if (predictionText != null) {

            val estimatedDays = calculateDaysToGoal(weightHistory, weightDates, goalWeight)

            predictionText.text = when {

                weightHistory.size < 2 -> "Log at least two entries to calculate prediction trend"
                estimatedDays == -2 -> "No changes in weight"
                estimatedDays > 0 -> "Estimated time to reach goal: $estimatedDays days"
                estimatedDays == 0 -> "Goal Weight Reached!"

                else -> "Currently moving away from goal weight"
            }
        }
    }

    //=============================================================================
    //Prediction algorithm: calculates days until user reaches their goal weight
    //=============================================================================
    private fun calculateDaysToGoal(

        weights: List<Float>,
        dates: List<String>,
        goalWeight: Float
    ): Int {

        val n = weights.size

        if (n < 2 || dates.size != n) {

            return -1
        }

        val currentWeight = weights.last()

        if (abs(currentWeight - goalWeight) < 0.1f) {

            return 0
        }

        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())

        val startDate = try {

            dateFormat.parse(dates.first())
        } catch (_: Exception) {

            null
        } ?: return -1

        val xValues = DoubleArray(n)

        for (i in dates.indices) {

            val parsedDate = try {

                dateFormat.parse(dates[i])
            } catch (_: Exception) {

                null
            } ?: return -1

            val diffInMillis = parsedDate.time - startDate.time
            xValues[i] = TimeUnit.MILLISECONDS.toDays(diffInMillis).toDouble()
        }

        var sumX = 0.0
        var sumY = 0.0
        var sumXY = 0.0
        var sumX2 = 0.0

        for (i in 0 until n) {

            val x = xValues[i]
            val y = weights[i].toDouble()

            sumX += x
            sumY += y
            sumXY += x * y
            sumX2 += x * x
        }

        val denominator = (n * sumX2 - sumX * sumX)

        if (denominator == 0.0) {

            return -1
        }

        val slope = (n * sumXY - sumX * sumY) / denominator
        val intercept = (sumY - slope * sumX) / n

        if (abs(slope) < 0.0001) {

            return -2
        }

        val isWeightLossGoal = goalWeight < currentWeight

        if (isWeightLossGoal && slope > 0) {

            return -1
        }

        if (!isWeightLossGoal && slope < 0) {

            return -1
        }

        val targetDayIndex = (goalWeight - intercept) / slope
        val currentDayIndex = xValues.last()
        val daysRemaining = ceil(targetDayIndex - currentDayIndex).toInt()

        return if (daysRemaining > 0) daysRemaining else -1
    }
}