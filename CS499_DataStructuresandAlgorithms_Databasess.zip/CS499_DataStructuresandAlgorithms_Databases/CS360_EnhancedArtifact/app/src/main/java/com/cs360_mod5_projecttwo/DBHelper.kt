package com.cs360_mod5_projecttwo

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper


//=============================================================================
//DBHelper manages SQLite Database creation, updates, and queries
//=============================================================================
class DBHelper(context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {

        //SQLite Database
        private const val DATABASE_NAME = "weight_tracker.db"
        private const val DATABASE_VERSION = 3

        //Three SQLite tables names
        private const val TABLE_USERS = "users"
        private const val TABLE_DAILY_WEIGHT = "daily_weight"
        private const val TABLE_GOAL_WEIGHT = "goal_weight"

        //Column names
        private const val COL_ID = "id"
        private const val COL_USER_ID = "user_id"
        private const val COL_WEIGHT = "weight"
        private const val COL_DATE = "date"
        private const val COL_SECURITY_ANSWER = "security_answer"
    }


    //=============================================================================
    //Create database tables
    //=============================================================================
    override fun onCreate(db: SQLiteDatabase) {

        //Enforce foreign key constraint
        db.execSQL("PRAGMA foreign_keys=ON;")

        //Users Table: Hold username and password of registered users
        val createUserTable = """
            CREATE TABLE IF NOT EXISTS $TABLE_USERS (
                $COL_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE,
                password TEXT,
                $COL_SECURITY_ANSWER TEXT
            )
        """
        db.execSQL(createUserTable)

        //Daily Weight Table: Hold logged weight with the date it was logged, will link this information to specific users
        val createDailyWeightTable = """
            CREATE TABLE IF NOT EXISTS $TABLE_DAILY_WEIGHT (
                $COL_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_USER_ID INTEGER,
                $COL_DATE TEXT,
                $COL_WEIGHT REAL,
                FOREIGN KEY($COL_USER_ID) REFERENCES $TABLE_USERS($COL_ID) ON DELETE CASCADE
            )
        """
        db.execSQL(createDailyWeightTable)

        //Goal Weight Table: Hold goal weight, will link this information to specific users
        val createGoalTable = """
            CREATE TABLE IF NOT EXISTS $TABLE_GOAL_WEIGHT (
                $COL_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_USER_ID INTEGER UNIQUE,
                $COL_WEIGHT REAL, 
                FOREIGN KEY($COL_USER_ID) REFERENCES $TABLE_USERS($COL_ID) ON DELETE CASCADE
            )
        """
        db.execSQL(createGoalTable)
    }

    //Reset tables on schema upgrade
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {

        db.execSQL("DROP TABLE IF EXISTS $TABLE_DAILY_WEIGHT")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_GOAL_WEIGHT")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_USERS")
        onCreate(db)
    }

    //Enable foreign key constraints
    override fun onConfigure(db: SQLiteDatabase) {

        super.onConfigure(db)
        db.setForeignKeyConstraintsEnabled(true)
    }


    //=============================================================================
    //User Management and Authentication Methods
    //=============================================================================

    //Register a new user and sets default goal weight
    //Returns generated user ID, if registration failed return -1L
    fun addUser(username: String, password: String, securityAnswer: String = ""): Long {

        val db = writableDatabase
        val values = ContentValues().apply {

            put("username", username)
            put("password", password)
            put(COL_SECURITY_ANSWER, securityAnswer.lowercase().trim())
        }

        val newUserId = db.insert(TABLE_USERS, null, values)

        if(newUserId != -1L) {

            val goalValues = ContentValues().apply {

                put(COL_USER_ID, newUserId)
                put(COL_WEIGHT, 150f)
            }

            db.insert(TABLE_GOAL_WEIGHT, null, goalValues)
        }

        return newUserId
    }

    //Authenticate user's credentials
    //Return user ID if authenticated, otherwise return -1 if authentication failed
    fun validateUser(username: String, password: String): Int {

        val db = readableDatabase
        val cursor = db.rawQuery(

            "SELECT $COL_ID FROM $TABLE_USERS WHERE username=? AND password=?",
            arrayOf(username, password)
        )

        var userId = -1

        if(cursor.moveToFirst()) {

            userId = cursor.getInt(0)
        }

        cursor.close()
        return userId
    }

    //Reset password if username and security question match
    fun resetPassword(username: String, securityAnswer: String, newPassword: String): Boolean {

        val db = writableDatabase
        val cursor = db.rawQuery("SELECT $COL_ID FROM $TABLE_USERS WHERE username=? AND $COL_SECURITY_ANSWER=?",
            arrayOf(username, securityAnswer.lowercase().trim()))

        val matches = cursor.moveToFirst()
        cursor.close()

        if(!matches) {

            return false
        }

        val values = ContentValues().apply {

            put("password", newPassword)
        }

        val rowsAffected = db.update(TABLE_USERS, values, "username=?", arrayOf(username))

        return rowsAffected > 0
    }


    //=============================================================================
    //User Management and Authentication Methods
    //=============================================================================

    //Adds a daily weight entry specific to the user
    fun addDailyWeight(userId: Int, date: String, weight: Float): Boolean {

        val db = writableDatabase
        val values = ContentValues().apply {

            put(COL_USER_ID, userId)
            put(COL_DATE, date)
            put(COL_WEIGHT, weight)
        }

        return db.insert(TABLE_DAILY_WEIGHT, null, values) != -1L
    }

    //Gets all weight logs for a specific user, then organize logs from newest to oldest
    //Return list of pairs: date, weight
    fun getAllDailyWeights(userId: Int): List<Pair<String, String>> {

        val db = readableDatabase
        val cursor = db.rawQuery("SELECT $COL_DATE, $COL_WEIGHT FROM $TABLE_DAILY_WEIGHT WHERE $COL_USER_ID=? ORDER BY $COL_ID DESC",
            arrayOf(userId.toString()))

        val list = mutableListOf<Pair<String, String>>()

        if(cursor.moveToFirst()) {

            do {

                val date = cursor.getString(0)
                val weight = cursor.getFloat(1).toString()

                list.add(date to weight)
            } while(cursor.moveToNext())
        }

        cursor.close()
        return list
    }

    //Get weight logs in chronological order from oldest to newest
    fun getChronologicalWeights(userId: Int): List<Float> {

        val db = readableDatabase
        val cursor = db.rawQuery("SELECT $COL_WEIGHT FROM $TABLE_DAILY_WEIGHT WHERE $COL_USER_ID=? ORDER BY $COL_ID ASC",
            arrayOf(userId.toString()))

        val weights = mutableListOf<Float>()

        if(cursor.moveToFirst()) {

            do{

                weights.add(cursor.getFloat(0))
            } while(cursor.moveToNext())
        }

        cursor.close()
        return weights
    }

    // Get dates in chronological order from oldest to newest
    fun getChronologicalDates(userId: Int): List<String> {
        val db = readableDatabase
        val cursor = db.rawQuery(
            "SELECT $COL_DATE FROM $TABLE_DAILY_WEIGHT WHERE $COL_USER_ID=? ORDER BY $COL_ID ASC",
            arrayOf(userId.toString())
        )

        val dates = mutableListOf<String>()

        if (cursor.moveToFirst()) {
            do {
                dates.add(cursor.getString(0))
            } while (cursor.moveToNext())
        }

        cursor.close()
        return dates
    }

    //Get the most recent weight log
    fun getLatestWeight(userId: Int): Float {

        val db = readableDatabase
        val cursor = db.rawQuery("SELECT $COL_WEIGHT FROM $TABLE_DAILY_WEIGHT WHERE $COL_USER_ID=? ORDER BY $COL_ID DESC LIMIT 1",
            arrayOf(userId.toString()))

        var latest = 0f

        if (cursor.moveToFirst()) {

            latest = cursor.getFloat(0)
        }

        cursor.close()
        return latest
    }


    //=============================================================================
    //Goal Weight Methods
    //=============================================================================

    //Get the goal weight
    fun getGoalWeight(userId: Int): Float {

        val db = readableDatabase
        val cursor = db.rawQuery("SELECT $COL_WEIGHT FROM $TABLE_GOAL_WEIGHT WHERE $COL_USER_ID=?",
            arrayOf(userId.toString()))

        var goal = 150f

        if (cursor.moveToFirst()) {

            goal = cursor.getFloat(0)
        }

        cursor.close()
        return goal
    }

    //Sets or updates the goal weight
    fun setGoalWeight(userId: Int, weight: Float) {

        val db = writableDatabase
        val values = ContentValues().apply {

            put(COL_USER_ID, userId)
            put(COL_WEIGHT, weight)
        }

        db.insertWithOnConflict( TABLE_GOAL_WEIGHT, null, values, SQLiteDatabase.CONFLICT_REPLACE)
    }
}
