package com.cs360_mod5_projecttwo

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

//=============================================================================
//Weight history adapter activity handles displaying the list of weight entries
//the user has logged over time
//=============================================================================
class WeightHistoryAdapter(private val data: List<Pair<String, String>>) :

    RecyclerView.Adapter<WeightHistoryAdapter.ViewHolder>() {

    //=============================================================================
    //ViewHolder class holds references to UI components for an individual list item
    //=============================================================================
    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val dateText: TextView = itemView.findViewById(R.id.weightDateText)
        val weightText: TextView = itemView.findViewById(R.id.weightValueText)
    }


    //Function inflates layout XML file and creates new ViewHolder instance
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {

        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_weight_entry, parent, false)

        return ViewHolder(view)
    }


    //Function binds data from data list to the view elements of a specific item position
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        val (date, weight) = data[position]

        holder.dateText.text = date
        holder.weightText.text = if(weight.endsWith("lbs")) weight else "$weight lbs"
    }

    //Function returns number of items held by the data set
    override fun getItemCount(): Int = data.size
}
