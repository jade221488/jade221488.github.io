package com.cs360_mod5_projecttwo

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

//=============================================================================
//Login handles user login and registration, passes user's ID to MainActivity
//=============================================================================
class LoginActivity : AppCompatActivity() {

    private lateinit var dbHelper: DBHelper

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        dbHelper = DBHelper(this)

        val usernameEditText = findViewById<EditText>(R.id.usernameEditText)
        val passwordEditText = findViewById<EditText>(R.id.passwordEditText)
        val loginButton = findViewById<Button>(R.id.loginButton)
        val registerText = findViewById<TextView>(R.id.registerText)
        val forgotPasswordText = findViewById<TextView>(R.id.forgotPasswordText)


        //=============================================================================
        //Login button handler
        //=============================================================================

        loginButton.setOnClickListener {

            val username = usernameEditText.text.toString().trim()
            val password = passwordEditText.text.toString().trim()

            if (username.isEmpty() || password.isEmpty()) {

                Toast.makeText(this, "Please enter username and password", Toast.LENGTH_SHORT).show()

                return@setOnClickListener
            }

            val userId = dbHelper.validateUser(username, password)

            if(userId != -1) {

                setUserSession(userId, username)

                Toast.makeText(this, "Login Successful!", Toast.LENGTH_SHORT).show()

                val intent = Intent(this, MainActivity::class.java).apply {

                    putExtra("USER_ID", userId)
                    putExtra("USERNAME", username)
                }

                startActivity(intent)

                finish()
            } else {

                Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show()
            }
        }


        //=============================================================================
        //User registration button handler
        //=============================================================================

        registerText.setOnClickListener {

            val username = usernameEditText.text.toString().trim()
            val password = passwordEditText.text.toString().trim()

            if (username.isEmpty() || password.isEmpty()) {

                Toast.makeText(this, "Please enter username and password", Toast.LENGTH_SHORT).show()

                return@setOnClickListener
            }

            val builder = AlertDialog.Builder(this)
            builder.setTitle("Account recovery setup")
            builder.setMessage("Enter security answer: What city were you born in?")

            val input = EditText(this).apply { hint = "Security Answer"}

            val container = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(50, 20, 50, 10)
                addView(input)
            }

            builder.setView(container)

            builder.setPositiveButton("Register") { dialog, _ ->

                val securityAnswer = input.text.toString().trim()

                if(securityAnswer.isEmpty()) {

                    Toast.makeText(this, "Security answer is required to recover account", Toast.LENGTH_SHORT).show()

                    return@setPositiveButton
                }

                val newUserId = dbHelper.addUser(username, password, securityAnswer)

                if(newUserId != 1L) {

                    Toast.makeText(this, "Account created successfully! Click Login to continue", Toast.LENGTH_LONG).show()

                    passwordEditText.text.clear()
                } else {
                    Toast.makeText(this, "Username already exists", Toast.LENGTH_SHORT).show()
                }

                dialog.dismiss()
            }

            builder.setNegativeButton("cancel") { dialog, _ -> dialog.cancel() }
            builder.show()
        }

        //=============================================================================
        //Forgot Password Handler
        //=============================================================================

        forgotPasswordText.setOnClickListener {

            getResetPasswordPopUp()
        }
    }


    //=============================================================================
    //Private functions
    //=============================================================================
    //Function that will prompt user secuirt answer verification to reset password
    private fun getResetPasswordPopUp(){

        val builder = AlertDialog.Builder(this)
        builder.setTitle("Reset Password")

        val layout = LinearLayout(this).apply {

            orientation = LinearLayout.VERTICAL
            setPadding(50, 20, 50, 10)
        }

        val usernameInput = EditText(this).apply { hint = "Username"}
        val securityInput = EditText(this).apply { hint = "Security Answer"}
        val newPasswordInput = EditText(this).apply { hint = "New Password"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }

        layout.addView(usernameInput)
        layout.addView(securityInput)
        layout.addView(newPasswordInput)
        builder.setView(layout)

        builder.setPositiveButton("Reset") { dialog, _ ->

            val user = usernameInput.text.toString().trim()
            val answer = securityInput.text.toString().trim()
            val newPass = newPasswordInput.text.toString().trim()

            if(user.isEmpty() || answer.isEmpty() || newPass.isEmpty()) {

                Toast.makeText(this, "All fields are required to reset password", Toast.LENGTH_SHORT).show()

                return@setPositiveButton
            }

            val success = dbHelper.resetPassword(user, answer, newPass)

            if(success) {

                Toast.makeText(this, "Password updated successfully! Click Log in!", Toast.LENGTH_LONG).show()
            } else {

                Toast.makeText(this, "Username or security answer is incorrect", Toast.LENGTH_LONG).show()
            }

            dialog.dismiss()
        }

        builder.setNegativeButton("Cancel") { dialog, _ -> dialog.cancel() }

        builder.show()
    }

    //Function that stores user details in SharedPreferences across app sessions
    private fun setUserSession(userId: Int, username: String) {

        val sharedPref = getSharedPreferences("UserSessionPrefs", Context.MODE_PRIVATE)

        with(sharedPref.edit()) {

            putInt("KEY_USER_ID", userId)
            putString("KEY_USERNAME", username)
            apply()
        }
    }
}
