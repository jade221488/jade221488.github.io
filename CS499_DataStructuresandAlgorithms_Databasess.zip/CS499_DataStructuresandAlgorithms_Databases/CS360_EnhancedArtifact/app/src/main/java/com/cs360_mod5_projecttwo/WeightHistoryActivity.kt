package com.cs360_mod5_projecttwo

import android.content.Intent
import android.widget.Toast
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView

//=============================================================================
//Weight history activity displays the user's weight entries and handles
//back to main screen
//=============================================================================
class WeightHistoryActivity : AppCompatActivity() {

    private lateinit var dbHelper: DBHelper
    private var currentUserId: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_weight_history)

        dbHelper = DBHelper(this)

        val sharedPref = getSharedPreferences("UserSessionPrefs", MODE_PRIVATE)

        currentUserId = intent.getIntExtra("USER_ID", sharedPref.getInt("KEY_USER_ID", -1))

        if(currentUserId == -1) {

            Toast.makeText(this, "Session expired. Please log in again", Toast.LENGTH_SHORT).show()

            val intent =Intent(this, LoginActivity::class.java)

            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)

            finish()
            return
        }

        val recyclerView = findViewById<RecyclerView>(R.id.weightRecyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)

        val weightData = dbHelper.getAllDailyWeights(currentUserId)
        recyclerView.adapter = WeightHistoryAdapter(weightData)

        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNavigationView)

        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> {

                    finish()
                    true
                }

                R.id.nav_history -> true
                else -> false
            }
        }
    }
}
