package com.cs360_mod5_projecttwo

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var dbHelper: DBHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_screen)

        dbHelper = DBHelper(this)

        val goalProgressBar = findViewById<ProgressBar>(R.id.goalProgressBar)
        val goalText = findViewById<TextView>(R.id.goalText)
        val todayWeightEditText = findViewById<EditText>(R.id.todayWeightEditText)
        val updateGoalButton = findViewById<Button>(R.id.updateGoalButton)
        val viewHistoryButton = findViewById<Button>(R.id.viewHistoryButton)
        val logWeightButton = findViewById<Button>(R.id.logWeightButton)

        // Initialize goal and progress
        refreshGoalAndProgress(goalProgressBar, goalText)

        // Update goal weight
        updateGoalButton.setOnClickListener {
            val goalInput = todayWeightEditText.text.toString()
            if (goalInput.isNotEmpty()) {
                val newGoal = goalInput.toFloat()
                dbHelper.updateGoalWeight(newGoal)
                todayWeightEditText.text.clear()
                refreshGoalAndProgress(goalProgressBar, goalText)
                Toast.makeText(this, "Goal weight updated", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Enter a new goal weight", Toast.LENGTH_SHORT).show()
            }
        }

        // Log today's weight
        logWeightButton.setOnClickListener {
            val weightText = todayWeightEditText.text.toString()
            if (weightText.isNotEmpty()) {
                val weight = weightText.toFloat()
                val date = SimpleDateFormat("MM/dd/yyyy", Locale.getDefault()).format(Date())
                dbHelper.addDailyWeight(date, weight)
                todayWeightEditText.text.clear()
                refreshGoalAndProgress(goalProgressBar, goalText)
                Toast.makeText(this, "Today's weight logged", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Enter today's weight first", Toast.LENGTH_SHORT).show()
            }
        }

        // View history button
        viewHistoryButton.setOnClickListener {
            val intent = android.content.Intent(this, WeightHistoryActivity::class.java)
            startActivity(intent)
        }
    }

    private fun refreshGoalAndProgress(progressBar: ProgressBar, goalText: TextView) {
        val goalWeight = dbHelper.getGoalWeight()
        val latestWeight = dbHelper.getLatestWeight()
        val progress = if (goalWeight != 0f) ((latestWeight / goalWeight) * 100).toInt() else 0
        progressBar.progress = progress
        goalText.text = "Goal: $goalWeight lbs"
    }
}
