package com.cs360_mod5_projecttwo

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView

class WeightHistoryActivity : AppCompatActivity() {

    private lateinit var dbHelper: DBHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_weight_history)

        dbHelper = DBHelper(this)

        val recyclerView = findViewById<RecyclerView>(R.id.weightRecyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)

        // Load all daily weights from DB
        val weightData = dbHelper.getAllDailyWeights()
        recyclerView.adapter = WeightHistoryAdapter(weightData)

        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNavigationView)
        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> {
                    finish() // Return to main screen
                    true
                }
                R.id.nav_history -> true
                else -> false
            }
        }
    }
}
