package com.cs360_mod5_projecttwo

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DBHelper(context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "weight_tracker.db"
        private const val DATABASE_VERSION = 1
    }

    override fun onCreate(db: SQLiteDatabase) {
        val createUserTable = """
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE,
                password TEXT
            )
        """
        db.execSQL(createUserTable)

        val createDailyWeightTable = """
            CREATE TABLE IF NOT EXISTS daily_weight (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                date TEXT,
                weight REAL
            )
        """
        db.execSQL(createDailyWeightTable)

        val createGoalTable = """
            CREATE TABLE IF NOT EXISTS goal_weight (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                weight REAL
            )
        """
        db.execSQL(createGoalTable)

        // Insert default goal weight
        val values = ContentValues().apply { put("weight", 150f) }
        db.insert("goal_weight", null, values)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS users")
        db.execSQL("DROP TABLE IF EXISTS daily_weight")
        db.execSQL("DROP TABLE IF EXISTS goal_weight")
        onCreate(db)
    }

    // User login methods
    fun checkUser(username: String, password: String): Boolean {
        val db = readableDatabase
        val cursor = db.rawQuery(
            "SELECT * FROM users WHERE username=? AND password=?",
            arrayOf(username, password)
        )
        val exists = cursor.count > 0
        cursor.close()
        return exists
    }

    fun addUser(username: String, password: String): Boolean {
        val db = writableDatabase
        val values = ContentValues().apply {
            put("username", username)
            put("password", password)
        }
        return db.insert("users", null, values) != -1L
    }

    // Daily weight methods
    fun addDailyWeight(date: String, weight: Float) {
        val db = writableDatabase
        val values = ContentValues().apply {
            put("date", date)
            put("weight", weight)
        }
        db.insert("daily_weight", null, values)
    }

    fun getAllDailyWeights(): List<Pair<String, String>> {
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT date, weight FROM daily_weight ORDER BY id DESC", null)
        val list = mutableListOf<Pair<String, String>>()
        if (cursor.moveToFirst()) {
            do {
                val date = cursor.getString(0)
                val weight = cursor.getFloat(1).toString()
                list.add(date to weight)
            } while (cursor.moveToNext())
        }
        cursor.close()
        return list
    }

    fun getLatestWeight(): Float {
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT weight FROM daily_weight ORDER BY id DESC LIMIT 1", null)
        var latest = 0f
        if (cursor.moveToFirst()) {
            latest = cursor.getFloat(0)
        }
        cursor.close()
        return latest
    }

    // Goal weight methods
    fun getGoalWeight(): Float {
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT weight FROM goal_weight LIMIT 1", null)
        var goal = 150f
        if (cursor.moveToFirst()) {
            goal = cursor.getFloat(0)
        }
        cursor.close()
        return goal
    }

    fun updateGoalWeight(weight: Float) {
        val db = writableDatabase
        val values = ContentValues().apply { put("weight", weight) }
        db.update("goal_weight", values, "id=?", arrayOf("1"))
    }
}
