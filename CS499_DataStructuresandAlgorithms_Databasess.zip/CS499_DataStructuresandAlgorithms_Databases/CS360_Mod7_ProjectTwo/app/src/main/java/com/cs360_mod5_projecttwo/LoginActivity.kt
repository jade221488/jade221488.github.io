package com.cs360_mod5_projecttwo

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {

    private lateinit var dbHelper: DBHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        dbHelper = DBHelper(this)

        val usernameEditText = findViewById<EditText>(R.id.usernameEditText)
        val passwordEditText = findViewById<EditText>(R.id.passwordEditText)
        val loginButton = findViewById<Button>(R.id.loginButton)
        val registerText = findViewById<TextView>(R.id.registerText)
        val forgotPasswordText = findViewById<TextView>(R.id.forgotPasswordText)

        // --- Login button ---
        loginButton.setOnClickListener {
            val username = usernameEditText.text.toString()
            val password = passwordEditText.text.toString()

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter username and password", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val userExists = dbHelper.checkUser(username, password)
            if (userExists) {
                Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show()
                // Go to SMS permission screen first
                val intent = Intent(this, SMSPermissionActivity::class.java)
                intent.putExtra("username", username)
                startActivity(intent)
                finish()
            } else {
                Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show()
            }
        }

        // --- New user registration ---
        registerText.setOnClickListener {
            val username = usernameEditText.text.toString()
            val password = passwordEditText.text.toString()

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter username and password", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val userExists = dbHelper.checkUser(username, password)
            if (userExists) {
                Toast.makeText(this, "User already exists", Toast.LENGTH_SHORT).show()
            } else {
                dbHelper.addUser(username, password)
                Toast.makeText(this, "User registered successfully", Toast.LENGTH_SHORT).show()
            }
        }

        // --- Forgot password ---
        forgotPasswordText.setOnClickListener {
            Toast.makeText(this, "Forgot password feature not implemented", Toast.LENGTH_SHORT).show()
        }
    }
}
