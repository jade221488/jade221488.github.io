package com.cs360_mod5_projecttwo

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class WeightHistoryAdapter(private val data: List<Pair<String, String>>) :
    RecyclerView.Adapter<WeightHistoryAdapter.ViewHolder>() {

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val dateText: TextView = itemView.findViewById(R.id.dateText)
        val weightText: TextView = itemView.findViewById(R.id.weightText)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_weight_history, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val (date, weight) = data[position]
        holder.dateText.text = date
        holder.weightText.text = weight
    }

    override fun getItemCount() = data.size
}
